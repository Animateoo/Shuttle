﻿/*
Â© Mateo Crespo (Animateo)

Puedes usar este plugin libremente.
No puedes venderlo, redistribuirlo ni publicar versiones modificadas.

Â¿Encontraste una mejora o correcciÃ³n?
Por favor, compÃ¡rtela con el autor.
*/
var d=new ActionReference(); d.putProperty(charIDToTypeID('Prpr'), stringIDToTypeID('targetLayersIDs')); d.putEnumerated(charIDToTypeID('Dcmn'), charIDToTypeID('Ordn'), charIDToTypeID('Trgt')); var desc=executeActionGet(d); var lst=desc.getList(stringIDToTypeID('targetLayersIDs')); var r=lst.getType(0); app.system('echo '+r+'> test_out.txt')