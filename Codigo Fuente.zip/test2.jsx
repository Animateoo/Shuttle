﻿/*
Â© Mateo Crespo (Animateo)

Puedes usar este plugin libremente.
No puedes venderlo, redistribuirlo ni publicar versiones modificadas.

Â¿Encontraste una mejora o correcciÃ³n?
Por favor, compÃ¡rtela con el autor.
*/
try { var app = new ActionReference(); ... } catch(e){}